Req 
Latest version of Google chrome or 35+
You can check the browser version by opening "chrome://chrome/" in google chrome

1.Visit chrome://extensions in your browser
2.Drag and drop Spritz.crx into the browser to install
